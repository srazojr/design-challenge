#! /usr/bin/env python
import Adafruit_BBIO.GPIO as GPIO
from Adafruit_I2C import Adafruit_I2C
import math

#HMC5883L 3 axis digital compass www.adafruit.com/datasheets/HMC5883L_3-Axis_Digital_Compass_IC.pdf
#ITG3205 mems gyro dl.btc.pl/kamami_wa/itg3205.pdf
#BMA180 acceleration irtfweb.ifa.hawaii.edu/~tcs3/...BMA180/BMA180-DataSheet-v2.5.pdf
#BMP085 pressure sensor https://www.sparkfun.com/datasheets/Components/General/BST-BMP085-DS000-05.pdf



BMA180= Adafruit_I2C(0x40)
BMP085= Adafruit_I2C(0x77)

#P8_23	imu7	A_INT1

#P8_27	imu9	P_XCLR
#P8_29	imu10	P_EOC


def twos_comp(val, bits):
    """compute the 2's compliment of int value val"""
    if( (val&(1<<(bits-1))) != 0 ):
        val = val - (1<<bits)
    return val
	
class compass:
	CONFIG_A = 0x00
	CONFIG_B = 0x01
	MODE_REG = 0x02
	DATAXMSB = 0x03
	DATAXLSB = 0x04
	DATAZMSB = 0x05
	DATAZLSB = 0x06
	DATAYMSB = 0x07
	DATAYLSB = 0x08
	STAT_REG = 0x09
	ID_REG_A = 0x0A
	ID_REG_B = 0x0B
	ID_REG_C = 0x0C
	TEMP_H=0x31
	TEMP_L=0x32
	DRDY ="P8_21"
	HMC5883L = Adafruit_I2C(0x1e)
	GAIN=1090
	GAIN_array=[1370,1090,820,660,440,390,330,230]
	GAUS_array=[.88,1.3,1.9,2.5,4.0,4.7,5.6,8.1]
	
	def set_samples_averaged(self,samples):#accepts 1,2,4,8
		if(samples==1 or samples==2 or samples==4 or samples==8 ):
			sa=int(math.log(samples,2))<<5
			ca=self.HMC5883L.readU8(self.CONFIG_A)&0x5f
			self.HMC5883L.write8(self.CONFIG_A,ca+sa)
			return 0
		return -1
	def set_output_rate_mode(self,rate):
		#0= 0.75HZ,1=1.5HZ,2=3HZ,3=7.5HZ,4=15HZdefault,5=30HZ,6=75HZ,7=reserved
		if(rate>=0 and rate<7):
			sa=rate<<2
			ca=self.HMC5883L.readU8(self.CONFIG_A)&0xe3
			self.HMC5883L.write8(self.CONFIG_A,ca+sa)
			return 0
		return -1 
	def set_measurement_mode(self,mode):
		#0=normal,1=positive bias,2=negative bias,3=reserved
		if(mode>=0 and mode<3):
			sa=mode
			ca=self.HMC5883L.readU8(self.CONFIG_A)&0xFC
			self.HMC5883L.write8(self.CONFIG_A,ca+sa)
			return 0
		return -1
	def set_gain_range(self,gaus):
		for x in range(0,8):
			if gaus<self.GAUS_array[x]:
				break
		self.GAIN=self.GAIN_array[x]
		self.HMC5883L.write8(self.CONFIG_B,x<<5)
		return 0
	def enable_i2c_highspeed(self):
		mr=self.HMC5883L.readU8(self.MODE_REG)&0x7f
		self.HMC5883L.write8(self.MODE_REG,mr+128)
		return 0
	def disable_i2c_highspeed(self):
		mr=self.HMC5883L.readU8(self.MODE_REG)&0x7f
		self.HMC5883L.write8(self.MODE_REG,mr)
		return 0
	def set_operating_mode(self,str):#"CONT","SING","IDLE"
		str=str.upper()[:4]
		if str=="CONT" :
			mr=self.HMC5883L.readU8(self.MODE_REG)&0xfc
			self.HMC5883L.write8(self.MODE_REG,mr)
			return 0
		elif str=="SING":
			mr=self.HMC5883L.readU8(self.MODE_REG)&0xfc
			self.HMC5883L.write8(self.MODE_REG,mr+1)
			return 0
		elif str=="IDLE":
			mr=self.HMC5883L.readU8(self.MODE_REG)&0xfc
			self.HMC5883L.write8(self.MODE_REG,mr+2)
			return 0
		else:
			return -1
	def __init__ (self,sample,rate,gain_range,highspeed,bias,mode):
		self.set_samples_averaged(sample)
		self.set_output_rate_mode(rate)
		self.set_gain_range(gain_range)
		if highspeed==1 :
			self.enable_i2c_highspeed()
		self.set_operating_mode(mode)
		self.set_measurement_mode(bias)
		GPIO.setup("P8_21", GPIO.IN)
		
	def get_operating_mode(self):
		mr=self.HMC5883L.readU8(self.MODE_REG)&0x03
		if mr==0 :
			return "CONT"
		if mr==1 :
			return "SING"
		return "IDLE"
	def get_x(self):
		return self.HMC5883L.readU8(self.DATAXMSB)*2**8+self.HMC5883L.readU8(self.DATAXLSB)
	def get_y(self):
		return self.HMC5883L.readU8(self.DATAYMSB)*2**8+self.HMC5883L.readU8(self.DATAYLSB)
	def get_z(self):
		return self.HMC5883L.readU8(self.DATAZMSB)*2**8+self.HMC5883L.readU8(self.DATAZLSB)
	def get_ID(self):
		return self.HMC5883L.readU8(self.ID_REG_C)*2**16+self.HMC5883L.readU8(self.ID_REG_B)* 2**8+self.HMC5883L.readU8(self.ID_REG_A)
	def data_locked(self):
		return self.HMC5883L.readU8(self.STAT_REG)&0x02>>1
	def RDY(self):
		return self.HMC5883L.readU8(self.STAT_REG)&0x01
	def DRDY(self):
		return GPIO.input("P8_21")
	def get(self):
		self.HMC5883L.write8(self.DATAXMSB,self.DATAXMSB)
		while 1:
			if 0==self.RDY():
				break
		x,xl,z,zl,y,yl=self.HMC5883L.readList( self.DATAXMSB, 6)
		t,tl=self.HMC5883L.readList( self.TEMP_H, 2)
		return twos_comp(x*2**8+xl,16),twos_comp(y*2**8+yl,16),twos_comp(z*2**8+zl,16)
		
		
def init():
			#sample,rate,gain_range,highspeed,bias,mode
	Compass=compass(8,4,5,0,1,"cont")
	
"""	
Compass.get_x(),Compass.get_y(),Compass.get_z()
Compass.data_locked()
Compass.get_operating_mode()

c1= compass(1,,4,,)
c2=compass(2,,8,)

c1.GAIN

"""


	
	
	
class gyro:
	ITG3205= Adafruit_I2C(0x68)
	WHO_AM_I=0x00
	SMPLRT_DIV=0x15
	DLPF_FS=0x16
	INT_CFG=0x17
	INT_STATUS=0x1A
	TEMP_OUT_H =0x1B 
	TEMP_OUT_L=0x1C 
	GYRO_XOUT_H=0x1D 
	GYRO_XOUT_L=0x1E 
	GYRO_YOUT_H=0x1F 
	GYRO_YOUT_L=0x20 
	GYRO_ZOUT_H =0x21
	GYRO_ZOUT_L =0x22 
	PWM_MGM=0x3E
	G_INT="P8_25"
	DLPF_CFG_IN=1000
	def __init__ (self):
		GPIO.setup(G_INT,GPIO.IN)
		return
	def verify(self):
		return  0x68==self.ITG3205.readU8(self.WHO_AM_I)
	def sample_rate_divider(self,frequency):
		SMPLRT_DIV_VAL=int(self.DLPF_CFG_IN/frequency-1)
		if SMPLRT_DIV_VAL>=0 and SMPLRT_DIV_VAL<=255:
			self.ITG3205.write8(self.SMPLRT_DIV,SMPLRT_DIV_VAL)
			return 0 
		return -1 
	def set_full_scale(self):
		dlpf=self.ITG3205.readU8(self.DLPF_FS)&0xe7
		self.ITG3205.write8(self.DLPF_FS,3<<3)
		return 0 
	def set_dlpf(self,mode):
		if mode>7 or mode<0:
			return -1
		dlpf=self.ITG3205.readU8(self.DLPF_FS)&0xf8
		if mode==0:
			DLPF_CFG_IN=8000
			self.ITG3205.write8(self.DLPF_FS,dlpf)
		else:
			DLPF_CFG_IN=1000
			self.ITG3205.write8(self.DLPF_FS,dlpf + mode)
		return 0 
	def int_actl(self,mode):#mode=1 for active low
		if mode==1 or mode==0:
			intcfg=self.ITG3205.readU8(self.INT_CFG)&0x7f
			self.ITG3205.write8(self.INT_CFG,mode<<7+intcfg)
			return 0 
		return -1 
	def int_open(self,mode):#mode=1 for open drain
		if mode==1 or mode==0:
			intcfg=self.ITG3205.readU8(self.INT_CFG)&0xbf
			self.ITG3205.write8(self.INT_CFG,mode<<6+intcfg)
			return 0 
		return -1
	def int_latch(self,mode):#mode=1 for latch until cleared
		if mode==1 or mode==0:
			intcfg=self.ITG3205.readU8(self.INT_CFG)&0xdf
			self.ITG3205.write8(self.INT_CFG,mode<<5+intcfg)
			return 0 
		return -1
	def int_anyrd(self,mode):#mode=1 any read clears, mode=0 only status reg read clears
		if mode==1 or mode==0:
			intcfg=self.ITG3205.readU8(self.INT_CFG)&0xef
			self.ITG3205.write8(self.INT_CFG,mode<<4+intcfg)
			return 0 
		return -1
	def int_rdy_en(self,mode):#mode=1 rdy_en int enabled
		if mode==1 or mode==0:
			intcfg=self.ITG3205.readU8(self.INT_CFG)&0xfb
			self.ITG3205.write8(self.INT_CFG,mode<<2+intcfg)
			return 0 
		return -1
	def int_raw_en(self,mode):#mode=1 raw_rdy_en int enabled
		if mode==1 or mode==0:
			intcfg=self.ITG3205.readU8(self.INT_CFG)&0xfe
			self.ITG3205.write8(self.INT_CFG,mode+intcfg)
			return 0 
		return -1
	def int_itgrdy_rawrdy(self):
		intstat=self.ITG3205.readU8(self.INT_STATUS)
		return  intstat&3 != 0, intstat&1 != 0
	def get(self):
		t,tl,x,xl,y,yl,z,zl=self.ITG3205.readList(self.TEMP_OUT_H,8)
		x,y,z,t=twos_comp(x*2**8+xl,16),twos_comp(y*2**8+yl,16),twos_comp(z*2**8+zl,16),twos_comp(t*2**8+tl,16)
		x,y,z,t=x/14.375,y/14.375,z/14.375,9*(35+(t+13200.0)/280.0)/5+32
		
		return  x,y,z,t
	def reset(self):
		pwmgt=self.ITG3205.readU8(self.PWM_MGM)&0x7f
		self.ITG3205.write8(self.PWM_MGM,pwmgt+128)
		return 0 
	def sleep(self):
		pwmgt=self.ITG3205.readU8(self.PWM_MGM)&0xbf
		self.ITG3205.write8(self.PWM_MGM,pwmgt+64)
		return 0 
	def awake(self):
		pwmgt=self.ITG3205.readU8(self.PWM_MGM)&0xbf
		self.ITG3205.write8(self.PWM_MGM,pwmgt)
		return 0 
	def stby_x(self,sleep):
		if sleep ==0 or sleep ==1:
			pwmgt=self.ITG3205.readU8(self.PWM_MGM)&0xdf
			self.ITG3205.write8(self.PWM_MGM,pwmgt+sleep<<5)
			return 0 
		return -1 
	def stby_y(self,sleep):
		if sleep ==0 or sleep ==1:
			pwmgt=self.ITG3205.readU8(self.PWM_MGM)&0xef
			self.ITG3205.write8(self.PWM_MGM,pwmgt+sleep<<4)
			return 0 
		return -1 
	def stby_z(self,sleep):
		if sleep ==0 or sleep ==1:
			pwmgt=self.ITG3205.readU8(self.PWM_MGM)&0xf7
			self.ITG3205.write8(self.PWM_MGM,pwmgt+sleep<<3)
			return 0 
		return -1 
	def set_clk_mode(self,mode):
		if mode<0 or mode>5:
			return -1 
		pwmgt=self.ITG3205.readU8(self.PWM_MGM)&0xf8
		self.ITG3205.write8(self.PWM_MGM,pwmgt+mode)
		return 0 
	def int_pin(self):
		return GPIO.input(G_INT)
	
	
	
class accel:
	BMA180= Adafruit_I2C(0x40)
	LSB_PER_G=.125#multiply by G range and then use as LSB per mg
	LSB_TEMP=.5#1 lsb=.5 degrees c
	
	reg_chip_id=0x00
	reg_version=0x01
	reg_acc_x_lsb=0x02
	reg_acc_x_msb=0x03
	reg_acc_y_lsb=0x04
	reg_acc_y_msb=0x05
	reg_acc_z_lsb=0x06
	reg_acc_z_msb=0x07
	reg_temp=0x08
	reg_status_reg1=0x9
	reg_status_reg2=0xA
	reg_status_reg3=0xb
	reg_status_reg4=0xc
	reg_ctrl_reg0=0xd 
	reg_ctrl_reg1=0xe 
	reg_ctrl_reg2=0xf  
	reg_reset=0x10
	reg_bw_tcs=0x20
	reg_
	